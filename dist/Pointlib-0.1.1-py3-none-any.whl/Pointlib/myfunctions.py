
def mutiple(a, b):
    return a * b